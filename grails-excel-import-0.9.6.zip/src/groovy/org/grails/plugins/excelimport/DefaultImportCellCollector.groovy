package org.grails.plugins.excelimport

import org.apache.poi.hssf.util.CellReference
import org.apache.poi.ss.usermodel.Cell
import org.apache.commons.logging.Log
import org.apache.commons.logging.LogFactory


class DefaultImportCellCollector implements ImportCellCollector  {

	static Log log = LogFactory.getLog(DefaultImportCellCollector.class)

	def problematicCellsBySeverityLevel = (ImportSeverityLevelEnum.enumConstants as List).inject([:]){acc, lvl ->
		acc[lvl] = [:]
		return acc
	}.asImmutable()

	@Override
	void reportCell(Cell cell, Object propertyConfiguration) {
		try {
		log.debug "Reporting cell $cell, config: $propertyConfiguration"
		def key = new CellReference(cell.sheet.sheetName, cell.rowIndex, cell.columnIndex, true, true).cellRefParts.toList()
		def value = [cell: cell, propertyConfiguration: propertyConfiguration]
		def severityMapping = propertyConfiguration?.severityMapping ?: ImportSeverityMappingEnum.IgnoreBlankWarningOtherwise
		def severityLevel = severityMapping.severityLevel(cell.cellType, propertyConfiguration?.expectedType)
		problematicCellsBySeverityLevel[severityLevel][key] = value
		} catch (e) {
			log.error "EXCEPTION CAUGHT ADSFAFDAFD $e"
		}
	}
}	
