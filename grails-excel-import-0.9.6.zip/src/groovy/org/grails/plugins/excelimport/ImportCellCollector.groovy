package org.grails.plugins.excelimport

import org.apache.poi.ss.usermodel.Cell


public interface ImportCellCollector {

	void reportCell(Cell cell, propertyConfiguration)

}
